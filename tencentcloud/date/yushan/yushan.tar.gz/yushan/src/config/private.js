const auth = {
  user: 'gain_in_your_wit@sina.cn',
  pass: '82f128f4c0b6fda0'
}
const host = "smtp.sina.cn"
export {
  auth,
  host
}