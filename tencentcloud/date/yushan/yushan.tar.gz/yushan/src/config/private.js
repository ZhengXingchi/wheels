const auth = {
  user: '',
  pass: ''
}
const host = ""
export {
  auth,
  host
}